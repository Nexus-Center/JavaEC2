package mouse.colector;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rafae
 */
public class WindowParameterTest {

    public static void main(String[] args) {
        WindowParameter detector = new WindowParameter(5000); // 5 seconds timeout
        while (true) {
            boolean isInactive = detector.isMouseInactive();
            System.out.println("Mouse is " + (isInactive ? "inactive" : "active"));
            try {
                Thread.sleep(1000); // wait for 1 second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
