/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mouse.colector;

import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.WinDef.POINT;
import com.sun.jna.platform.win32.WinDef.RECT;
import com.sun.jna.platform.win32.WinDef.HWND;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

/**
 *
 * @author rafae
 */
public class WindowParameter {

    private POINT lastMousePosition;
    private long lastActivityTime;
    private final long timeout;
    private final GraphicsDevice[] screens;

    public WindowParameter(long timeout) {
        this.timeout = timeout;
        lastMousePosition = getMousePosition();
        lastActivityTime = System.currentTimeMillis();
        System.out.println("Mouse initialized at " + lastMousePosition);
        screens = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices();
    }

    public boolean isMouseInactive() {
        POINT currentMousePosition = getMousePosition();
        if (!currentMousePosition.equals(lastMousePosition)) {
            lastMousePosition = currentMousePosition;
            lastActivityTime = System.currentTimeMillis();
            System.out.println("Mouse moved to " + currentMousePosition + " at " + lastActivityTime);
        }
        boolean isInactive = System.currentTimeMillis() - lastActivityTime > timeout;
        if (isInactive) {
            System.out.println("Mouse is inactive since " + lastActivityTime);
        }
        return isInactive;
    }

    private POINT getMousePosition() {
        POINT point = new POINT();
        WinDef.HWND hwnd = User32.INSTANCE.GetForegroundWindow();
        User32.INSTANCE.GetCursorPos(point);
        RECT rect = new RECT();
        User32.INSTANCE.GetClientRect(hwnd, rect);
        User32.INSTANCE.GetClientRect(hwnd, rect);
        point.x -= rect.left;
        point.y -= rect.top;

        // Convert window coordinates to screen coordinates
        GraphicsDevice screen = getScreen(hwnd);
        GraphicsConfiguration config = screen.getDefaultConfiguration();
        point.x = config.getBounds().x + point.x;
        point.y = config.getBounds().y + point.y;

        return point;
    }

    private GraphicsDevice getScreen(HWND hwnd) {
        RECT rect = new RECT();
        User32.INSTANCE.GetWindowRect(hwnd, rect);

        for (GraphicsDevice screen : screens) {
            GraphicsConfiguration config = screen.getDefaultConfiguration();
            if (config.getBounds().contains(rect.toRectangle())) {
                return screen;
            }
        }
        return GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
    }

}
