/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mouse.colector;

import com.sun.jna.platform.win32.WinDef;

/**
 *
 * @author rafae
 */
public class MouseTeste {
    public static void main(String[] args) {
        MouseColector novaposicao= new MouseColector(0);
        WinDef.POINT posicao = novaposicao.getMousePosition();
        System.out.println(posicao);
    }
}
