/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nexus.conector.jdbc;

import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author rafael_aldo < https://github.com/rafasptech >
 */
public class QuerryUsuario {

    public static void main(String[] args) {
        Conexao conexao = new Conexao();
        JdbcTemplate conn = conexao.getConnection();

//        Executando o comando de insert com Maquina
//        Maquina novoUsuario = new Maquina();
//        novoUsuario.setId(5);
    //    novoUsuario.setNome("Harry Potter");
    //    novoUsuario.setSenha("123432");
    //    novoUsuario.setEmail("harry@harry");
     //   novoUsuario.setFkCodigoDeEmpresa("159160");

    //    con.update("insert into usuario values (?,?,?)",
       //         novoUsuario.getId(),
       //         novoUsuario.getNome(),
      //          novoUsuario.getSenha());
      //  novoUsuario.getEmail();
      //  novoUsuario.getFkCodigoDeEmpresa();;

//        Lista com tipo
        List<Maquina> listaDeUsuariosComTipo = conn.query("select * from maquina WHERE patrimonio = 'SA10567' AND senha = '1'",
                new BeanPropertyRowMapper(Maquina.class));

        System.out.println(listaDeUsuariosComTipo);

//  

    }
}
