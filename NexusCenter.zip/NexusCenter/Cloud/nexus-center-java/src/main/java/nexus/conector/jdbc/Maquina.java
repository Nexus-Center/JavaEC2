/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nexus.conector.jdbc;

/**
 *
 * @author rafael_aldo < https://github.com/rafasptech >
 */
public class Maquina {

    private Integer idMaquina;
    private String nomeUsuario;
    private String patrimonio;
    private String senha;
    private Integer fkEmpresa;

    public Integer getidMaquina() {
        return idMaquina;
    }

    public Integer getIdMaquina() {
        return idMaquina;
    }

    public void setIdMaquina(Integer idMaquina) {
        this.idMaquina = idMaquina;
    }

   

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public String getPatrimonio() {
        return patrimonio;
    }

    public void setPatrimonio(String patrimonio) {
        this.patrimonio = patrimonio;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Integer getFkEmpresa() {
        return fkEmpresa;
    }

    public void setFkEmpresa(Integer fkEmpresa) {
        this.fkEmpresa = fkEmpresa;
    }

    @Override
    public String toString() {
        return String.format("idMáquina: %d | Nome Usuário: %s | Patrimonio: %s | Senha : %s|fkEmpresa: %d |",idMaquina,nomeUsuario,patrimonio,senha,fkEmpresa);
    }
}
