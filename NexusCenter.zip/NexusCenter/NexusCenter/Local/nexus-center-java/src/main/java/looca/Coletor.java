/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package looca;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.discos.Disco;
import com.github.britooo.looca.api.group.discos.DiscoGrupo;
import com.github.britooo.looca.api.group.dispositivos.DispositivoUsb;
import com.github.britooo.looca.api.group.memoria.Memoria;
import com.github.britooo.looca.api.group.processador.Processador;
import com.github.britooo.looca.api.group.processos.ProcessoGrupo;
import com.github.britooo.looca.api.group.processos.Processo;
import com.github.britooo.looca.api.group.sistema.Sistema;
import com.github.britooo.looca.api.group.dispositivos.DispositivosUsbGrupo;









import java.util.List;

/**
 *
 * @author rafae
 */
public class Coletor {

public void resultadoLooca() {
    Looca looca = new Looca();
        Sistema sistema = looca.getSistema();

        sistema.getPermissao();
        sistema.getFabricante();
        sistema.getArquitetura();
        sistema.getInicializado();
        sistema.getSistemaOperacional();

        System.out.println(sistema);
        
//      Querry da memória
        
        Memoria memoria= looca.getMemoria();
        
        memoria.getDisponivel();
        memoria.getEmUso();
        memoria.getTotal();
        
        System.out.println(memoria);
        
//        Querry Processador:
        
        Processador processador= looca.getProcessador();
        
        processador.getFabricante();
        processador.getFrequencia();
        processador.getId();
        processador.getIdentificador();
        processador.getMicroarquitetura();
        processador.getNumeroCpusFisicas();
        processador.getNumeroCpusLogicas();
        processador.getNumeroPacotesFisicos();
        processador.getUso();
        
        System.out.println(processador);
        

        
//      Querry relativo a coleta de dados do Disco:

        DiscoGrupo grupoDeDiscos = looca.getGrupoDeDiscos();

        List<Disco> discos = grupoDeDiscos.getDiscos();

        for (Disco disco : discos) {
            System.out.println(disco);
        }
        
      // Querry dados de Processos:

        ProcessoGrupo grupoDeProcessos = looca.getGrupoDeProcessos();
        
       List<Processo> processos = grupoDeProcessos.getProcessos();
       
        for (Processo processo : processos) {
          System.out.println(processo);
     }
       
        // Querrys de coleta do Periférico
        DispositivosUsbGrupo dispositivos = looca.getDispositivosUsbGrupo();
        List<DispositivoUsb> dispositosConectados = dispositivos.getDispositivosUsbConectados();

        for (DispositivoUsb dispositivo : dispositosConectados) {
            System.out.println(dispositivo);
        }
        
    }
}
